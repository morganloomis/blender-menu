# Script discovery: scan directory for .py files with main(), build menu tree.
# Uses AST only; does not import or execute user code.

import ast
import os
from dataclasses import dataclass, field

from .labels import format_menu_label


@dataclass
class ScriptItem:
    """A script file that defines main(). label is the menu label (e.g. filename without .py)."""
    label: str
    path: str


@dataclass
class FolderNode:
    """A folder in the menu tree: subfolders and scripts, sorted by name."""
    subfolders: list[tuple[str, "FolderNode"]] = field(default_factory=list)
    scripts: list[ScriptItem] = field(default_factory=list)


def tree_has_menus(node: FolderNode) -> bool:
    """Return True when the tree has subfolders or root-level scripts with main()."""
    if node.subfolders:
        return True
    return bool(node.scripts)


def _has_main(source: str) -> bool:
    """Return True if the Python source defines a function named main. Uses AST only."""
    try:
        tree = ast.parse(source)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "main":
                return True
        return False
    except SyntaxError:
        return False


def _scan_folder(dir_path: str) -> FolderNode:
    """Scan a directory and build a FolderNode. Sorts subfolders and scripts lexicographically."""
    node = FolderNode()
    if not os.path.isdir(dir_path):
        return node
    try:
        entries = sorted(os.scandir(dir_path), key=lambda e: e.name.lower())
    except OSError:
        return node
    for entry in entries:
        if entry.name.startswith("."):
            continue
        if entry.is_dir():
            child = _scan_folder(entry.path)
            node.subfolders.append((entry.name, child))
        elif entry.is_file() and entry.name.endswith(".py"):
            try:
                with open(entry.path, "r", encoding="utf-8", errors="replace") as f:
                    source = f.read()
            except OSError:
                continue
            if _has_main(source):
                stem = os.path.splitext(entry.name)[0]
                node.scripts.append(ScriptItem(label=format_menu_label(stem), path=entry.path))
    return node


def build_script_tree(root_path: str) -> FolderNode | None:
    """
    Build the menu tree for the given script root path.
    Returns a FolderNode with top-level subfolders and scripts, or None if root_path
    is invalid (missing, not a directory, or empty). Does not raise.
    """
    if not root_path or not root_path.strip():
        return None
    path = os.path.abspath(os.path.expanduser(root_path.strip()))
    if not os.path.isdir(path):
        return None
    return _scan_folder(path)


def merge_folder_nodes(nodes: list[FolderNode]) -> FolderNode:
    """Merge folder trees; later nodes override scripts with the same menu label."""
    result = FolderNode()
    if not nodes:
        return result

    subfolder_children: dict[str, list[FolderNode]] = {}
    for node in nodes:
        for name, child in node.subfolders:
            subfolder_children.setdefault(name, []).append(child)

    for name in sorted(subfolder_children.keys(), key=lambda n: n.lower()):
        merged_child = merge_folder_nodes(subfolder_children[name])
        result.subfolders.append((name, merged_child))

    script_by_label: dict[str, ScriptItem] = {}
    for node in nodes:
        for script in node.scripts:
            script_by_label[script.label] = script

    result.scripts = sorted(script_by_label.values(), key=lambda s: s.label.lower())
    return result


def build_merged_script_tree(root_paths: list[str]) -> tuple[FolderNode | None, list[str]]:
    """
    Build a merged menu tree from multiple script root paths.
    Returns (tree, skipped_paths) where skipped_paths lists invalid paths.
    tree is None when no valid paths remain.
    """
    trees: list[FolderNode] = []
    skipped: list[str] = []

    for path in root_paths:
        tree = build_script_tree(path)
        if tree is None:
            skipped.append(path)
        else:
            trees.append(tree)

    if not trees:
        return None, skipped

    return merge_folder_nodes(trees), skipped
